create
    definer = root@localhost function ch_lineitem_ava(user_id int, prod_id int, size varchar(45)) returns int
BEGIN
    DECLARE res int;

 select count(*) into res
 from cart join line_cart on cart.id=line_cart.id_cart
 join lineitem on lineitem.id=line_cart.id_line 
 join product on lineitem.id_prod=product.id 
 where cart.id_user=user_id 
 and cart.active="yes" 
 and lineitem.id_prod=prod_id
 and lineitem.size=size;
 IF res > 0 then
 RETURN 0;
 ELSE
 RETURN 1;
END IF;
    
END;

