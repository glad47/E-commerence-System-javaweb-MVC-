create
    definer = root@localhost function cal_tot_tax(user_id int) returns float
BEGIN
    DECLARE tax float;

   select 
sum(lineitem.quantity * product.price *0.05 ) into tax 
 from cart join line_cart on cart.id=line_cart.id_cart
 join lineitem on lineitem.id=line_cart.id_line 
 join product on lineitem.id_prod=product.id 
where cart.id_user=user_id and cart.active="yes"; 

    RETURN tax;
END;

