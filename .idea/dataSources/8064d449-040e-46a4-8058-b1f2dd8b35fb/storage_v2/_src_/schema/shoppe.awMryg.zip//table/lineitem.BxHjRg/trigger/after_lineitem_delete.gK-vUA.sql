create definer = root@localhost trigger after_lineitem_delete
    after delete
    on lineitem
    for each row
BEGIN
delete from line_cart where  line_cart.id_line=old.id ;
END;

